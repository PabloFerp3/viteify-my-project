"use client"

import { ArrowLeft } from "lucide-react"
import { useI18n } from "@/lib/i18n-context"

const legalContent: Record<string, { title: string; sections: { heading: string; text: string }[] }> = {
  privacidad: {
    title: "Politica de Privacidad",
    sections: [
      {
        heading: "1. Responsable del tratamiento",
        text: "Veloso Industrial, con domicilio en Bembrive-Vigo, Pontevedra (Espana), es el responsable del tratamiento de los datos personales que el usuario proporcione a traves de este sitio web. Correo electronico de contacto: info.talleresveloso@gmail.com. Telefono: 623258421.",
      },
      {
        heading: "2. Finalidad del tratamiento de datos",
        text: "Los datos personales recabados a traves del formulario de contacto seran tratados con la finalidad de gestionar y responder a las consultas, solicitudes de informacion o presupuestos realizados por los usuarios. Los datos no seran utilizados para finalidades distintas a las descritas.",
      },
      {
        heading: "3. Legitimacion del tratamiento",
        text: "La base legal para el tratamiento de sus datos es el consentimiento del usuario al enviar el formulario de contacto, asi como el interes legitimo del responsable para atender las solicitudes recibidas.",
      },
      {
        heading: "4. Destinatarios de los datos",
        text: "Los datos personales no seran cedidos a terceros salvo obligacion legal. No se realizan transferencias internacionales de datos.",
      },
      {
        heading: "5. Derechos del usuario",
        text: "El usuario puede ejercer sus derechos de acceso, rectificacion, supresion, portabilidad, limitacion y oposicion al tratamiento de sus datos personales dirigiendose a info.talleresveloso@gmail.com, adjuntando copia de su documento de identidad.",
      },
      {
        heading: "6. Conservacion de datos",
        text: "Los datos personales proporcionados se conservaran durante el tiempo necesario para dar respuesta a la consulta y, en su caso, durante los plazos legalmente establecidos.",
      },
    ],
  },
  cookies: {
    title: "Politica de Cookies",
    sections: [
      {
        heading: "1. Que son las cookies",
        text: "Las cookies son pequenos archivos de texto que los sitios web almacenan en el navegador del usuario. Se utilizan para recordar preferencias, mejorar la experiencia de navegacion y recopilar informacion anonima sobre el uso del sitio.",
      },
      {
        heading: "2. Tipos de cookies que utilizamos",
        text: "Cookies tecnicas: Necesarias para el funcionamiento basico del sitio web. Permiten la navegacion y el uso de las diferentes opciones y servicios. Cookies analiticas: Nos permiten cuantificar el numero de usuarios y realizar la medicion y analisis estadistico de la utilizacion del sitio web.",
      },
      {
        heading: "3. Gestion de cookies",
        text: "El usuario puede configurar su navegador para aceptar o rechazar todas las cookies, o para recibir un aviso en pantalla de la recepcion de cada cookie y decidir en ese momento su aceptacion o no. La desactivacion de cookies puede afectar al correcto funcionamiento del sitio web.",
      },
      {
        heading: "4. Cookies de terceros",
        text: "Este sitio web puede utilizar servicios de terceros que, por cuenta propia, recopilan informacion con fines estadisticos y de uso del sitio web por parte del usuario.",
      },
      {
        heading: "5. Actualizacion de la politica de cookies",
        text: "Veloso Industrial puede modificar esta Politica de Cookies en funcion de nuevas exigencias legislativas, reglamentarias o con la finalidad de adaptar dicha politica a las instrucciones dictadas por la Agencia Espanola de Proteccion de Datos.",
      },
    ],
  },
  "aviso-legal": {
    title: "Aviso Legal",
    sections: [
      {
        heading: "1. Datos identificativos",
        text: "En cumplimiento del deber de informacion recogido en la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Informacion y del Comercio Electronico (LSSICE), se facilitan los siguientes datos: Titular: Veloso Industrial. Domicilio: Bembrive-Vigo, Pontevedra (Espana). Contacto: info.talleresveloso@gmail.com | 623258421.",
      },
      {
        heading: "2. Objeto",
        text: "El presente aviso legal regula el uso y las condiciones de acceso al sitio web de Veloso Industrial, cuyo contenido es de caracter informativo sobre los servicios de soldadura, montaje de tuberia, caldereria ligera, reparaciones y mantenimientos que ofrece la empresa.",
      },
      {
        heading: "3. Propiedad intelectual e industrial",
        text: "Todos los contenidos del sitio web, incluyendo textos, fotografias, graficos, imagenes, iconos, tecnologia, software, enlaces y demas contenidos audiovisuales o sonoros, asi como su diseno grafico y codigos fuente, son propiedad intelectual de Veloso Industrial o de terceros, sin que puedan entenderse cedidos al usuario ninguno de los derechos de explotacion.",
      },
      {
        heading: "4. Condiciones de uso",
        text: "El usuario se compromete a hacer un uso adecuado de los contenidos y servicios que Veloso Industrial ofrece a traves de su sitio web y a no emplearlos para incurrir en actividades ilicitas o contrarias a la buena fe y al ordenamiento legal.",
      },
      {
        heading: "5. Exclusion de responsabilidad",
        text: "Veloso Industrial no se hace responsable de la informacion y contenidos almacenados en foros, redes sociales o cualquier otro medio que permita a terceros publicar contenidos de forma independiente en la pagina web del prestador.",
      },
      {
        heading: "6. Legislacion aplicable y jurisdiccion",
        text: "Para la resolucion de todas las controversias o cuestiones relacionadas con el presente sitio web o de las actividades en el desarrolladas, sera de aplicacion la legislacion espanola, a la que se someten expresamente las partes, siendo competentes para la resolucion de todos los conflictos derivados o relacionados con su uso los Juzgados y Tribunales de Vigo.",
      },
    ],
  },
}

interface LegalPageProps {
  type: string
  onBack: () => void
}

export function LegalPage({ type, onBack }: LegalPageProps) {
  const { t } = useI18n()
  const content = legalContent[type]

  if (!content) return null

  return (
    <section className="py-24 sm:py-32">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <button
          onClick={onBack}
          className="mb-8 flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
        >
          <ArrowLeft className="h-4 w-4" />
          {t("legal.volver")}
        </button>

        <h1 className="mb-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          {content.title}
        </h1>
        <div className="mb-10 h-1 w-16 bg-primary" />

        <div className="space-y-8">
          {content.sections.map((section, index) => (
            <div key={index}>
              <h2 className="mb-3 text-lg font-semibold text-foreground">
                {section.heading}
              </h2>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {section.text}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-lg border border-border bg-card p-6">
          <p className="text-xs leading-relaxed text-muted-foreground">
            {t("legal.actualizacion")}
          </p>
        </div>
      </div>
    </section>
  )
}
